Télé du Net XBMC plugin
=======================

#### About the service ####
Télé du Net is a free online broadcasting service based in Tunisia that is dedicated to online viewers that live outside the Arab world.

It broadcasts channels through the internet 24/7. The service is completely free to use and has a great compilation of channels to choose from.

Using the XBMC plugin
---------------------
#### Installation ####
Install the **[Arabic XBMC addons repository](https://github.com/hadynz/repository.arabic.xbmc-addons#arabic-xbmc-repository)** and select to install this plugin from it.

#### Configuration #####
No configuration is required for this plugin.